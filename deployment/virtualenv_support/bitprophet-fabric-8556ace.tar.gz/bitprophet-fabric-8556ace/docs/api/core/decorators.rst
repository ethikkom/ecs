==========
Decorators
==========

.. automodule:: fabric.decorators
    :members: hosts, roles, runs_once
